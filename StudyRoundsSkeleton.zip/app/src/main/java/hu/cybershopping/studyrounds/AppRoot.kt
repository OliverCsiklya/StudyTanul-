package hu.cybershopping.studyrounds

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun AppRoot() {
    Text("StudyRounds is running")
}
