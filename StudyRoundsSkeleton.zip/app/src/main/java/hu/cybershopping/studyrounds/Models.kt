package hu.cybershopping.studyrounds

data class StudyRound(
    val title: String,
    val points: List<String>
)
