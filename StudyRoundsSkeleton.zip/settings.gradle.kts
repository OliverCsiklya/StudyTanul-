rootProject.name = "StudyRoundsSkeleton"
include(":app")
